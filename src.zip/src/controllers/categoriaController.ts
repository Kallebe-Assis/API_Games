import { Request, Response } from 'express';
import {
    alterarCategoria,
    buscarCategoriasFiltro,
    buscarCategoriasId,
    criarCategoria,
    deletarCategoria
} from '../database/categoriaData';

// Buscar categorias com filtro e paginação
export const getCategorias = async (req: Request, res: Response): Promise<void> => {
    try {
        const { nome, pag = 1, limite = 3 } = req.query;
        const pagNumber = Number(pag);
        const limiteNumber = Number(limite);

        if (isNaN(pagNumber) || pagNumber <= 0 || isNaN(limiteNumber) || limiteNumber <= 0) {
            throw new Error("Os parâmetros 'pag' e 'limite' devem ser números positivos.");
        }

        const result = await buscarCategoriasFiltro(nome as string, pagNumber, limiteNumber);

        if (!result || result.length === 0) {
            res.status(404).json({ message: "Nenhuma categoria encontrada com os filtros fornecidos." });
            return;
        }

        res.json(result);
    } catch (error: any) {
        const message = error.sqlMessage || error.message || "Erro interno ao buscar categorias.";
        res.status(500).json({ message });
    }
};

// Buscar categoria por ID
export const getCategoriaById = async (req: Request, res: Response): Promise<void> => {
    try {
        const idCategoriaBuscado = Number(req.params.id);
        const limiteNumber = req.params.limite ? Number(req.params.limite) : 3;
        const pagNumber = req.params.pagNumber ? Number(req.params.pagNumber) : 1;

        if (isNaN(idCategoriaBuscado) || idCategoriaBuscado <= 0) {
            throw new Error("Erro: o ID deve ser um número positivo.");
        }

        const result = await buscarCategoriasId(idCategoriaBuscado, pagNumber, limiteNumber);

        if (!result || result.length === 0) {
            res.status(404).json({ message: "Categoria não encontrada com o ID fornecido." });
            return;
        }

        res.json(result[0]);
    } catch (error: any) {
        const message = error.sqlMessage || error.message || "Erro interno ao buscar categoria por ID.";
        res.status(500).json({ message });
    }
};

// Criar nova categoria
export const postCategoria = async (req: Request, res: Response): Promise<void> => {
    const { nomeCategoria } = req.body;

    try {
        if (!nomeCategoria || typeof nomeCategoria !== "string") {
            throw new Error("O nome da categoria é obrigatório e deve ser uma string válida.");
        }

        const categoriaCriada = await criarCategoria(nomeCategoria);
        res.status(201).json(categoriaCriada);
    } catch (error: any) {
        const message = error.sqlMessage || error.message || "Erro interno ao criar categoria.";
        res.status(500).json({ message });
    }
};

// Alterar categoria existente
export const putCategoria = async (req: Request, res: Response): Promise<void> => {
    const { idCategoria } = req.params;
    const { nomeCategoria, tipoCategoria } = req.body;

    try {
        if (!idCategoria || isNaN(Number(idCategoria))) {
            throw new Error("ID da categoria inválido. Deve ser um número positivo.");
        }

        if (!nomeCategoria && !tipoCategoria) {
            throw new Error("Informe pelo menos um campo para alterar (nomeCategoria ou tipoCategoria).");
        }

        const resultado = await alterarCategoria(Number(idCategoria), nomeCategoria, tipoCategoria);

        if (!resultado) {
            res.status(404).json({ message: "Categoria não encontrada para alteração." });
            return;
        }

        res.json({ message: "Categoria alterada com sucesso.", categoriaAtualizada: resultado });
    } catch (error: any) {
        const message = error.sqlMessage || error.message || "Erro interno ao alterar categoria.";
        res.status(500).json({ message });
    }
};

// Deletar categoria por ID
export const deleteCategoria = async (req: Request, res: Response): Promise<void> => {
    const { idCategoria } = req.params;

    try {
        if (!idCategoria || isNaN(Number(idCategoria))) {
            throw new Error("ID da categoria inválido. Deve ser um número positivo.");
        }

        const resultado = await deletarCategoria(Number(idCategoria));

        res.json({ message: `Categoria com ID ${idCategoria} deletada com sucesso.` });
    } catch (error: any) {
        const message = error.sqlMessage || error.message || "Erro interno ao deletar categoria.";
        res.status(500).json({ message });
    }
};
