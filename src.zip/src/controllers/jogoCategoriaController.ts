import { Request, Response } from 'express';
import { buscarJogosPorCategoria } from '../database/jogoCategoriaDATA';

export const buscarJogosPorCategoriaController = async (req: Request, res: Response): Promise<void> => {
    const { idCategoria } = req.params;

    try {
        // Verifica se o idCategoria é um número válido
        if (isNaN(Number(idCategoria)) || Number(idCategoria) <= 0) {
            res.status(400).json({ message: 'ID da categoria inválido. Deve ser um número positivo.' });
            return;
        }

        // Convertendo o idCategoria para número
        const jogosECategoria = await buscarJogosPorCategoria(Number(idCategoria));

        if (jogosECategoria.length === 0) {
            res.status(404).json({ message: 'Nenhum jogo encontrado para esta categoria' });
            return;
        }

        // Retorna os dados encontrados
        res.json(jogosECategoria);
    } catch (error: any) {
        const message = error.message || 'Erro ao buscar jogos por categoria';
        res.status(500).json({ message });
    }
};
