// controllers/jogoController.ts

import { Request, Response } from 'express';
import { buscarJogosFiltro, buscarJogosId, atualizarJogo, deletarJogo } from '../database/jogoData';
import connection from '../database/dbClient';

// GET que busca os jogos com possibilidade de filtro por QUERY
export const getJogos = async (req: Request, res: Response): Promise<void> => {
    try {
        const { nome, anolancamento, idademinima, pag = 1, limite = 3 } = req.query;
        const pagNumber = Number(pag);
        const limiteNumber = Number(limite);

        if (isNaN(pagNumber) || pagNumber <= 0 || isNaN(limiteNumber) || limiteNumber <= 0) {
            res.status(400).json({ message: "Os parâmetros 'pag' e 'limite' devem ser números positivos." });
            return;
        }

        if (anolancamento && isNaN(Number(anolancamento))) {
            res.status(400).json({ message: "O parâmetro 'anolancamento' deve ser um número válido." });
            return;
        }

        if (idademinima && isNaN(Number(idademinima))) {
            res.status(400).json({ message: "O parâmetro 'idademinima' deve ser um número válido." });
            return;
        }

        const ano = anolancamento ? Number(anolancamento) : undefined;
        const idade = idademinima ? Number(idademinima) : undefined;

        const result = await buscarJogosFiltro(nome as string, ano, idade, pagNumber, limiteNumber);
        res.json(result);
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// GET que busca o jogo por ID
export const getJogoById = async (req: Request, res: Response): Promise<void> => {
    try {
        const idJogoBuscado = Number(req.params.id);

        if (!req.params.id || isNaN(idJogoBuscado) || idJogoBuscado <= 0) {
            res.status(400).json({ message: "ID inválido" });
            return;
        }

        const limiteNumber = req.params.limite ? Number(req.params.limite) : 3;
        const pagNumber = req.params.pagNumber ? Number(req.params.pagNumber) : 1;

        const result = await buscarJogosId(idJogoBuscado, pagNumber, limiteNumber);

        if (result.length === 0) {
            res.status(404).json({ message: "Jogo não encontrado" });
            return;
        }

        res.json(result[0]);
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// POST Criar um novo jogo
export const createJogo = async (req: Request, res: Response): Promise<void> => {
    try {
        const novoJogo = req.body;

        if (!novoJogo.nome || !novoJogo.anolancamento || !novoJogo.descricao || !novoJogo.idademinima) {
            res.status(400).json({ message: "É necessário informar todos os dados para adicionar um novo jogo" });
            return;
        }

        const [id] = await connection('jogo').insert({
            nomejogo: novoJogo.nome,
            anolancamento: novoJogo.anolancamento,
            descricaojogo: novoJogo.descricao,
            idademinima: novoJogo.idademinima
        }).returning('idjogo');

        res.status(201).json({
            message: "Jogo Adicionado com Sucesso !!!",
            jogo: { ...novoJogo, idJogo: id }
        });
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// PUT Alterar um jogo
export const updateJogo = async (req: Request, res: Response): Promise<void> => {
    try {
        const idJogo = Number(req.params.id);

        if (isNaN(idJogo) || idJogo <= 0) {
            res.status(400).json({ message: "ID inválido" });
            return;
        }

        const dadosAtualizados = req.body;

        if (!dadosAtualizados.nomejogo && !dadosAtualizados.anolancamento && !dadosAtualizados.descricaojogo && !dadosAtualizados.idademinima) {
            res.status(400).json({ message: "Todos os dados são necessários para atualizar o jogo." });
            return;
        }

        const jogoAtualizado = await atualizarJogo(idJogo, dadosAtualizados);

        if (!jogoAtualizado) {
            res.status(404).json({ message: "Jogo não encontrado para atualização." });
            return;
        }

        res.json({
            message: "Jogo atualizado com Sucesso !!!",
            jogo: jogoAtualizado,
        });
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// DELETE Deletar um jogo
export const deleteJogo = async (req: Request, res: Response): Promise<void> => {
    try {
        const idJogo = Number(req.params.idJogo);

        if (isNaN(idJogo) || idJogo <= 0) {
            res.status(400).json({ message: "ID inválido" });
            return;
        }

        const resultado = await deletarJogo(idJogo);

        if (resultado && resultado.message) {
            res.json({ message: resultado.message });
        } else {
            res.status(500).json({ message: "Erro desconhecido ao excluir o jogo." });
        }

        res.json({ message: `Jogo com id ${idJogo} excluído com sucesso` });
    } catch (error: any) {
        const message = error.message || 'Erro ao excluir o jogo';
        res.status(500).json({ message });
    }
};
