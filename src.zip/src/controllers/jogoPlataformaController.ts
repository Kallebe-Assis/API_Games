import { Request, Response } from 'express';
import { buscarJogosPorPlataforma } from '../database/jogoPlataformaData';

export const buscarJogosPorPlataformaController = async (req: Request, res: Response): Promise<void> => {
    const { idPlataforma } = req.params;

    // Verificar se o idPlataforma é um número válido
    if (isNaN(Number(idPlataforma))) {
        res.status(400).json({ message: 'idPlataforma deve ser um número válido.' });
        return;
    }

    try {
        // Convertendo o idPlataforma para número, já que ele vem como string na URL
        const jogosEPlataforma = await buscarJogosPorPlataforma(Number(idPlataforma));

        if (jogosEPlataforma.length === 0) {
            res.status(404).json({ message: 'Nenhum jogo encontrado para esta plataforma.' });
            return;
        }

        // Retorna os dados encontrados
        res.json(jogosEPlataforma);
    } catch (error: any) {
        const message = error.message || 'Erro ao buscar jogos por plataforma';
        res.status(500).json({ message });
    }
};
