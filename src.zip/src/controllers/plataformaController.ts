// controllers/plataformaController.ts

import { Request, Response } from 'express';
import { buscarPlataformasFiltro, buscarPlataformasId, criarPlataforma, alterarPlataforma, deletarPlataforma } from '../database/plataformaData';

// GET que busca as plataformas com filtros
export const getPlataformas = async (req: Request, res: Response): Promise<void> => {
    try {
        const { nome, tipo, pag = 1, limite = 3 } = req.query;
        const pagNumber = Number(pag);
        const limiteNumber = Number(limite);

        if (isNaN(pagNumber) || pagNumber <= 0 || isNaN(limiteNumber) || limiteNumber <= 0) {
            res.status(400).json({ message: "Os parâmetros 'pag' e 'limite' devem ser números positivos." });
            return;
        }

        const result = await buscarPlataformasFiltro(nome as string, tipo as string, pagNumber, limiteNumber);
        res.json(result);
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// GET que busca a plataforma por ID
export const getPlataformaById = async (req: Request, res: Response): Promise<void> => {
    try {
        const idPlataformaBuscado = Number(req.params.id);

        if (isNaN(idPlataformaBuscado) || idPlataformaBuscado <= 0) {
            res.status(400).json({ message: "ID inválido" });
            return;
        }

        const limiteNumber = req.params.limite ? Number(req.params.limite) : 3;
        const pagNumber = req.params.pagNumber ? Number(req.params.pagNumber) : 1;

        const result = await buscarPlataformasId(idPlataformaBuscado, pagNumber, limiteNumber);

        if (result.length === 0) {
            res.status(404).json({ message: "Plataforma não encontrada" });
            return;
        }

        res.json(result[0]);
    } catch (error: any) {
        const message = error.sqlMessage || error.message;
        res.status(500).json({ message });
    }
};

// POST para criar uma nova plataforma
export const createPlataforma = async (req: Request, res: Response): Promise<void> => {
    const { nomePlataforma, tipoPlataforma } = req.body;

    try {
        if (!nomePlataforma || !tipoPlataforma) {
            res.status(400).json({ message: "Nome da plataforma e tipo são obrigatórios." });
            return;
        }

        const plataformaCriada = await criarPlataforma(nomePlataforma, tipoPlataforma);
        res.status(201).json({ message: "Plataforma criada com sucesso", plataforma: plataformaCriada });
    } catch (error: any) {
        const message = error.message || 'Erro ao criar plataforma';
        res.status(500).json({ message });
    }
};

// PUT para atualizar uma plataforma
export const updatePlataforma = async (req: Request, res: Response): Promise<void> => {
    const { idPlataforma } = req.params;
    const { nomePlataforma, tipoPlataforma } = req.body;

    try {
        const resultado = await alterarPlataforma(Number(idPlataforma), nomePlataforma, tipoPlataforma);
        res.status(200).json(resultado);
    } catch (error: any) {
        const message = error.message || 'Erro ao atualizar plataforma';
        res.status(500).json({ message });
    }
};

// DELETE para deletar uma plataforma
export const deletePlataforma = async (req: Request, res: Response): Promise<void> => {
    const { idPlataforma } = req.params;

    try {
        await deletarPlataforma(Number(idPlataforma));
        res.json({ message: `Plataforma com ID ${idPlataforma} deletada com sucesso.` });
    } catch (error: any) {
        const message = error.message || 'Erro ao deletar plataforma';
        res.status(500).json({ message });
    }
};
