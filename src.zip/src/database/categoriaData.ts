import connection from "./dbClient";

export const buscarCategoriasFiltro = async (nome?: string, pag: number = 1, limite: number = 3) => {
    try {
        // Validação dos parâmetros 'pag' e 'limite'
        if (pag <= 0) {
            const error = new Error('O número da página (pag) deve ser maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }
        if (limite <= 0) {
            const error = new Error('O limite (limite) deve ser maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        const offset = (pag - 1) * limite;

        const query = connection("categoria")
            .select("*")
            .limit(limite)
            .offset(offset);

        if (nome) {
            query.where("nomecategoria", "ilike", `%${nome}%`);
        }

        const resultado = await query;

        if (resultado.length === 0) {
            const error = new Error('Nenhuma categoria encontrada para o filtro fornecido.');
            (error as any).status = 404; // Not Found
            throw error;
        }

        return resultado;

    } catch (error: any) {
        if (!error.status) {
            
            error.status = 500; // Internal Server Error
            error.message = error.message || 'Erro interno ao buscar categorias no banco de dados.';
        }
        throw error;
    }
}

export const buscarCategoriasId = async (id?: number, pag: number = 1, limite: number = 3) => {
    try {
        // Validação dos parâmetros 'id', 'pag' e 'limite'
        if (!id || id <= 0) {
            const error = new Error('O ID da categoria deve ser fornecido e ser maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        if (pag <= 0) {
            const error = new Error('O número da página (pag) deve ser maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        if (limite <= 0) {
            const error = new Error('O limite (limite) deve ser maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        const offset = (pag - 1) * limite;

        const query = connection("categoria")
            .select("*")
            .limit(limite)
            .offset(offset)
            .where("idcategoria", id);

        const resultado = await query;

        // Erro se nao encontrar categoria
        if (resultado.length === 0) {
            const error = new Error('Nenhuma categoria encontrada para o ID fornecido.');
            (error as any).status = 404; // Not Found
            throw error;
        }

        return resultado;

    } catch (error: any) {

        if (!error.status) {
            error.status = 500; // Internal Server Error
            error.message = error.message || 'Erro interno ao buscar a categoria no banco de dados.';
        }
        throw error;
    }
};

// ALTERAR CATEGORIA
export const alterarCategoria = async (idCategoria: number, nomeCategoria: string, tipoCategoria: string) => {
    try {
        // Verificando se a categoria existe
        const categoriaExistente = await connection('categoria')
            .where('idcategoria', idCategoria)
            .first();

        if (!categoriaExistente) {
            throw new Error('Categoria não encontrada.');
        }

        // Atualizando a categoria
        const resultado = await connection('categoria')
            .where('idcategoria', idCategoria)
            .update({
                nomecategoria: nomeCategoria,
                tipocategoria: tipoCategoria
            });

        if (resultado) {
            return { message: 'Categoria atualizada com sucesso.' };
        } else {
            throw new Error('Erro ao atualizar categoria.');
        }
    } catch (error: any) {
        throw new Error(error.message || 'Erro ao atualizar categoria');
    }
};

// DELETAR CATEGORIA
export const deletarCategoria = async (idCategoria: number): Promise<void> => {
    try {
        console.log(`Deletando categoria com ID: ${idCategoria}`);

        const resultado = await connection("categoria")
            .where("idcategoria", idCategoria)
            .del();

        // return resultado.rowCount; // Retorna o número de linhas afetadas
        console.log(`Categoria com ID ${idCategoria} deletada com sucesso.`);
    } catch (error) {
        console.error("Erro ao deletar categoria:", error);
        throw new Error("Erro ao deletar categoria no banco de dados.");
    }
    
};

// CRIAR CATEGORIA
export const criarCategoria = async (nomeCategoria: string) => {
    try {
        console.log(`Tentando criar categoria: ${nomeCategoria}`);

        // Executa a query para inserir a nova categoria
        const [novaCategoria] = await connection('categoria')
            .insert({ nomecategoria: nomeCategoria })
            .returning('*'); // Retorna todos os dados da categoria criada

        return novaCategoria; // Retorna a categoria criada
    } catch (error) {
        console.error('Erro ao criar categoria:', error);
        throw new Error('Erro ao criar a categoria no banco de dados.');
    }
};

