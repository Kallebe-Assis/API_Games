// src/dbClient.ts
import knex from 'knex';
import * as dotenv from 'dotenv';

dotenv.config(); // Carrega as variáveis de ambiente

const connection = knex({
    client: 'postgres',
    connection: {
        user: process.env.DB_USER,
        host: process.env.DB_HOST,
        database: process.env.DB_NAME,
        password: process.env.DB_PASSWORD,
        port: Number(process.env.DB_PORT)
    }
});

export default connection;
