import connection from "./dbClient";

export const buscarJogosPorCategoria = async (idCategoria: number) => {
    try {
         // Verifica se o idCategoria é válido
         if (!idCategoria || idCategoria <= 0) {
            const error = new Error('idCategoria deve ser um número válido e maior que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        console.log(`Buscando jogos para a categoria com idCategoria=${idCategoria}`);
        
        // Executa a query com INNER JOIN entre as tabelas "jogo_categoria" e "categoria"
        const resultado = await connection("jogo_categoria as jc")
            .join("jogo as j", "jc.idjogo", "j.idjogo") // Ajustando para o nome correto da tabela "jogo" e colunas em minúsculas
            .join("categoria as c", "jc.idcategoria", "c.idcategoria") // Ajustando para o nome correto da tabela "categoria" e colunas em minúsculas
            .select("j.idjogo", "j.nomejogo", "c.nomecategoria") // Selecionando as colunas em minúsculas
            .where("jc.idcategoria", idCategoria); // Filtra pelo idCategoria (em minúsculas)


        // Verifica se o resultado está vazio
        if (resultado.length === 0) {
            const error = new Error('Nenhum jogo encontrado para a categoria fornecida.');
            (error as any).status = 404; // Not Found
            throw error;
        }

        console.log("Resultado encontrado:", resultado);
        return resultado;

    } catch (error: any) {

        if (!error.status) {
            error.status = 500; // Internal Server Error
            error.message = error.message || 'Erro ao buscar jogos por categoria no banco de dados.';
        }
        throw error;
    }
};
