import connection from "./dbClient";

export const buscarJogosFiltro = async (nome?: string, ano?: number, idade?: number, pag: number = 1, limite: number = 3) => {
    try{

        // Verifica se os parâmetros de página e limite são números válidos
        if (pag <= 0 || limite <= 0) {
            const error = new Error('Os parâmetros de página (pag) e limite devem ser maiores que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        const offset = (pag - 1) * limite;

        const query = connection("jogo")
            .select("*")
            .limit(limite)
            .offset(offset);

        if (nome) {
            query.where("nome", "ilike", `%${nome}%`);
        }

        if (ano) {
            query.where("anolancamento", ano);
        }

        if (idade) {
            query.where("idademinima", ">=", idade);
        }

        const resultado = await query;

        // Verifica se o resultado está vazio
        if (resultado.length === 0) {
            const error = new Error('Nenhum jogo encontrado para os filtros fornecidos.');
            (error as any).status = 404; // Not Found
            throw error;
        }

        return resultado;

    } catch(error: any) {
        if(!error.status) {
            error.status = 500;
            error.message = error.message || 'Erro ao buscar jogos com os filtros fonecidos.';
        }
        throw error;
    }
}

export const buscarJogosId = async (id?: number, pag: number = 1, limite: number = 3) => {
    try{
        
        if (pag <= 0 || limite <= 0) {
            const error = new Error('Os parâmetros de página (pag) e limite devem ser maiores que zero.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        if (!id) {
            const error = new Error('O id do jogo é obrigatório.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        const offset = (pag - 1) * limite;

        const query = connection("jogo")
            .select("*")
            .limit(limite)
            .offset(offset);

            query.where("idjogo", id);
   

        return query;

    } catch (error: any) {

        if (!error.status) {
            error.status = 500; // Internal Server Error
            error.message = error.message || 'Erro ao buscar jogo com o id fornecido.';
        }
        throw error;
    }
}

export const atualizarJogo = async (idjogo: number, dados: any) => {
    try{
        
        if (!dados || Object.keys(dados).length === 0) {
            const error = new Error('Os dados a serem atualizados não podem ser vazios.');
            (error as any).status = 400; // Bad Request
            throw error;
        }

        console.log("Atualizando jogo com ID:", idjogo);
        console.log("Dados a serem atualizados:", dados);

        // Verifica se o jogo com o id informado existe
        const jogoExistente = await connection('jogo')
            .select('*')
            .where({ idjogo })
            .first();

        if (!jogoExistente) {
            const error = new Error('Jogo não encontrado com o ID fornecido.');
            (error as any).status = 404; // Not Found
            throw error;
        }

        // Atualiza os dados do jogo
        const result = await connection('jogo')
            .where({ idjogo }) // Filtra pelo ID do jogo
            .update(dados) // Atualiza os dados passados
            .returning('*'); // Retorna todos os campos do registro atualizado

        if (result.length === 0) {
            const error = new Error('Erro ao atualizar o jogo.');
            (error as any).status = 500; // Internal Server Error
            throw error;
        }

        return result[0]; // Retorna o primeiro resultado (jogo atualizado)

    } catch (error: any) {

        if (!error.status) {
            error.status = 500; // Internal Server Error
            error.message = error.message || 'Erro ao atualizar o jogo.';
        }

        throw error;
    }
};

export const deletarJogo = async (idJogo: number) => {
    try {

        if (!idJogo || isNaN(idJogo)) {
            const error = new Error("O ID do jogo fornecido é inválido.");
            (error as any).status = 400; // Bad Request
            throw error;
        }

        console.log(`Tentando excluir o jogo com idJogo=${idJogo}`);

        const jogoExistente = await connection("jogo")
            .select("*")
            .where("idjogo", idJogo)
            .first();

        if (!jogoExistente) {
            const error = new Error("Jogo não encontrado com o ID fornecido.");
            (error as any).status = 404; // Not Found
            throw error;
        }

        // Executa a query para excluir o jogo pela coluna idJogo
        const resultado = await connection("jogo")
            .where("idjogo", idJogo)
            .del(); // Deleta o jogo com o idJogo especificado

        if (resultado === 0) {
            const error = new Error("Nenhum jogo foi excluído. Ocorreu um erro desconhecido.");
            (error as any).status = 500; // Internal Server Error
            throw error;
        }

        console.log(`Jogo com idJogo=${idJogo} excluído com sucesso.`);
        return { message: "Jogo excluído com sucesso." };

    } catch (error: any) {

        if (!error.status) {
            error.status = 500;
            error.message = error.message || "Erro ao excluir o jogo.";
        }
        console.error("Erro ao excluir jogo:", error.message);
        throw error;
    }
};