import connection from "./dbClient";

export const buscarJogosPorPlataforma = async (idPlataforma: number) => {
    try {
        console.log(`Buscando jogos para a plataforma com idPlataforma=${idPlataforma}`);

        // Executa a query com INNER JOIN entre as tabelas "jogo_plataforma" e "plataforma"
        const resultado = await connection("jogo_plataforma as jp")
            .join("jogo as j","jp.idjogo","j.idjogo") // Ajustando para o nome correto da tabela "jogo"
            .join("paltaforma as p","jp.idplataforma","p.idplataforma") // Ajustando para o nome correto da tabela "plataforma"
            .select("j.idjogo","j.nomejogo","p.nomeplataforma") // Selecionando as colunas de jogo e plataforma 
            .where("jp.idplataforma", idPlataforma) // Filtro pelo idPlataforma

        if (resultado.length === 0) {
            console.log("Nenhum jogo encontrado para a plataforma fornecida.");
            return[]; // Retorna um array vazio se nao encontrar resultados
        } else {
            console.log("Resultado encontrado:", resultado);
            return resultado; // Retorna o resultado com jogos e o nome da plataforma
        }
        
    } catch (error: any) {

        // Captura e trata erros específicos relacionados ao banco de dados
        if (error.code === 'ECONNREFUSED') {
            console.error("Erro de conexão com o banco de dados:", error);
            throw new Error("Falha na conexão com o banco de dados.");
        }

        // Erro relacionado à consulta SQL (como erros de sintaxe)
        if (error.code === 'ER_PARSE_ERROR') {
            console.error("Erro na sintaxe da query SQL:", error);
            throw new Error("Erro de sintaxe na consulta SQL.");
        }

        // Erro genérico de banco de dados
        console.error("Erro ao buscar jogos por plataforma:", error);
        throw new Error("Erro ao buscar jogos por plataforma no banco de dados.");
    }
};