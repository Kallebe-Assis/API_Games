import connection from "./dbClient";

export const buscarPlataformasFiltro = async (nome?: string, tipo?: string, pag: number = 1, limite: number = 3) => {
    try {

        if (pag <= 0 || limite <= 0) {
            const error = new Error("Os valores de 'pag' e 'limite' devem ser maiores que zero.");
            (error as any).status = 400; // Bad Request
            throw error;
        }

        const offset = (pag - 1) * limite;

        const query = connection("plataforma")
            .select("*")
            .limit(limite)
            .offset(offset);

        if (nome) {
            query.where("nomeplataforma", "ilike", `%${nome}%`);
        }
        if (tipo) {
            query.where("tipoplataforma", "ilike", `%${tipo}%`);
        }

        const resultado = await query;

        if (resultado.length === 0) {
            console.log("Nenhuma plataforma encontrada com os filtros fornecidos.");
            return []; // Retorna um array vazio se nenhum resultado for encontrado
        }

        console.log(`Plataformas encontradas:`, resultado);
        return resultado;

    } catch (error: any) {
        console.error("Erro ao buscar plataformas com filtro:", error.message);
        throw new Error("Erro ao buscar plataformas no banco de dados.");
    }
};

export const buscarPlataformasId = async (id?: number, pag: number = 1, limite: number = 3) => {
    try {

        if (!id || isNaN(id)) {
            throw new Error("O ID da plataforma deve ser um número válido.");
        }

        const offset = (pag - 1) * limite;

        const query = connection("plataforma")
            .select("*")
            .limit(limite)
            .offset(offset)
            .where("idplataforma", id);

        const resultado = await query;

        if (resultado.length === 0) {
            console.log("Nenhuma plataforma encontrada com o ID fornecido.");
            return [];
        }

        console.log("Resultado encontrado:", resultado);
        return resultado;

    } catch (error) {

        console.error("Erro ao buscar plataformas por ID:", error);
        throw new Error("Erro ao buscar plataformas no banco de dados.");
    }
}

export const atualizarPlataforma = async (idplataforma: number, dados: any) => {
    try {
        console.log("Atualizando plataforma com ID:", idplataforma);
        console.log("Dados a serem atualizados:", dados);

        if (!idplataforma || isNaN(idplataforma)) {
            throw {
                status: 400,
                message: "O ID da plataforma deve ser um número válido.",
            };
        }

        if (!dados || Object.keys(dados).length === 0) {
            throw {
                status: 400,
                message: "Os dados para atualização não podem estar vazios.",
            };
        }

        const result = await connection("plataforma")
            .where({ idplataforma }) // Filtra pelo ID da plataforma
            .update(dados) // Atualiza os dados passados
            .returning("*"); // Retorna todos os campos do registro atualizado

        // Verifica se algum registro foi atualizado
        if (result.length === 0) {
            throw {
                status: 404,
                message: "Nenhuma plataforma encontrada com o ID fornecido.",
            };
        }

        console.log("Plataforma atualizada com sucesso:", result[0]);
        return result[0];
    } catch (error: any) {
        console.error("Erro ao atualizar plataforma:", error);

        throw new Error(error.message || "Erro ao atualizar plataforma no banco de dados.");
    }
};

export const criarPlataforma = async (nomePlataforma: string, tipoPlataforma: string) => {
    try {
        console.log(`Tentando criar plataforma: ${nomePlataforma}`);

        if (!nomePlataforma || typeof nomePlataforma !== "string" || nomePlataforma.trim().length === 0) {
            throw {
                status: 400,
                message: "O nome da plataforma é obrigatório e deve ser uma string válida.",
            };
        }

        if (!tipoPlataforma || typeof tipoPlataforma !== "string" || tipoPlataforma.trim().length === 0) {
            throw {
                status: 400,
                message: "O tipo da plataforma é obrigatório e deve ser uma string válida.",
            };
        }

        // Executa a query para inserir a nova plataforma
        const [novaPlataforma] = await connection("plataforma")
            .insert({
                nomeplataforma: nomePlataforma,
                tipoplataforma: tipoPlataforma
            })
            .returning("*"); // Retorna todos os dados da plataforma criada

        console.log("Plataforma criada com sucesso:", novaPlataforma);
        return novaPlataforma; // Retorna a plataforma criada

    } catch (error) {
        console.error("Erro ao criar plataforma:", error);
        throw new Error("Erro ao criar a plataforma no banco de dados.");
    }
};

// ALTERAR PLATAFORMA
export const alterarPlataforma = async (idPlataforma: number, nomePlataforma: string, tipoPlataforma: string) => {
    try {
        // Verificando se a plataforma existe
        const plataformaExistente = await connection('plataforma')
            .where('idplataforma', idPlataforma)
            .first();

        if (!plataformaExistente) {
            throw new Error('Plataforma não encontrada.');
        }

        // Atualizando a plataforma
        const resultado = await connection('plataforma')
            .where('idplataforma', idPlataforma)
            .update({
                nomeplataforma: nomePlataforma,
                tipoplataforma: tipoPlataforma
            });

        if (resultado) {
            return { message: 'Plataforma atualizada com sucesso.' };
        } else {
            throw new Error('Erro ao atualizar plataforma.');
        }
    } catch (error: any) {
        throw new Error(error.message || 'Erro ao atualizar plataforma');
    }
};

// DELETAR PLATAFORMA
export const deletarPlataforma = async (idPlataforma: number): Promise<void> => {
    try {
        console.log(`Deletando plataforma com ID: ${idPlataforma}`);

        if (!idPlataforma || isNaN(idPlataforma)) {
            throw {
                status: 400,
                message: "O ID da plataforma deve ser um número válido.",
            };
        }

        const resultado = await connection("plataforma")
            .where("idplataforma", idPlataforma)
            .del();

        if (resultado === 0) {
            throw new Error("Plataforma não encontrada para o ID fornecido.");
        }

        console.log(`Plataforma com ID ${idPlataforma} deletada com sucesso.`);
    } catch (error) {
        console.error("Erro ao deletar plataforma:", error);
        throw new Error("Erro ao deletar plataforma no banco de dados.");
    }
};