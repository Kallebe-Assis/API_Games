import cors from 'cors';
import * as dotenv from 'dotenv';
import express from 'express';
import categoriasRoute from './routes/categoriasRoute';
import jogoCategoriaRoute from './routes/jogoCategoriaRoute';
import jogosRoute from './routes/jogosRoute';
import plataformasRoute from './routes/plataformasRoute';
import jogoPlataformaRoute from './routes/jogoPlataformaRoute';



dotenv.config(); //Configuração do .env

//Comecin do express  (linhas magicas);
const app = express();
app.use(express.json());
app.use(cors());

app.use('/jogos', jogosRoute); //Os endpoint dos jogos
app.use('/categorias', categoriasRoute); //Os endpoint das categorias
app.use('/plataformas', plataformasRoute); //Os endpoint das plataformas
app.use('/jogo-categoria', jogoCategoriaRoute); //Os endpoint da junção de jogo com categoria.
app.use('/jogo-plataforma', jogoPlataformaRoute); //Os endpoint da junção de jogo com categoria.


const port = process.env.PORT || 3003;

app.listen(port, () => {
    console.log(`Server is running in http://localhost:${port}`);
})

export default app;
