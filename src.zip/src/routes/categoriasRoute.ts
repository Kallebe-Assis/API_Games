import { Router } from 'express';
import {
    deleteCategoria,
    getCategoriaById,
    getCategorias,
    postCategoria,
    putCategoria
} from '../controllers/categoriaController';

const router = Router();

// Rotas de categorias
router.get('/', getCategorias); // Buscar com filtro/paginação
router.get('/:id/:limite?/:pagNumber?', getCategoriaById); // Buscar por ID
router.post('/', postCategoria); // Criar nova categoria
router.put('/:idCategoria', putCategoria); // Alterar categoria
router.delete('/:idCategoria', deleteCategoria); // Deletar categoria

export default router;
