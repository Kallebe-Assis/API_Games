import { Router } from 'express';
import { buscarJogosPorCategoriaController } from '../controllers/jogoCategoriaController';

const router = Router();

// Rota GET para buscar jogos por categoria
router.get('/:idCategoria', buscarJogosPorCategoriaController);

export default router;
