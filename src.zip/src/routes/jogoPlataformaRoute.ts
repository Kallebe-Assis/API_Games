import { Router } from 'express';
import { buscarJogosPorPlataformaController } from '../controllers/jogoPlataformaController';

const router = Router();

// Rota GET para buscar jogos por plataforma
router.get('/:idPlataforma', buscarJogosPorPlataformaController);

export default router;
