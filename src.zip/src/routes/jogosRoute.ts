// routes/jogoRoutes.ts

import { Router } from 'express';
import {
    getJogos,
    getJogoById,
    createJogo,
    updateJogo,
    deleteJogo
} from '../controllers/jogoController';

const router = Router();

// Rotas
router.get('/', getJogos);
router.get('/:id/:limite?/:pagNumber', getJogoById);
router.post('/', createJogo);
router.put('/:id', updateJogo);
router.delete('/:idJogo', deleteJogo);

export default router;
