// routes/plataformaRoutes.ts

import { Router } from 'express';
import {
    getPlataformas,
    getPlataformaById,
    createPlataforma,
    updatePlataforma,
    deletePlataforma
} from '../controllers/plataformaController';

const router = Router();

// Rotas
router.get('/', getPlataformas);
router.get('/:id/:limite?/:pagNumber', getPlataformaById);
router.post('/', createPlataforma);
router.put('/:idPlataforma', updatePlataforma);
router.delete('/:idPlataforma', deletePlataforma);

export default router;
